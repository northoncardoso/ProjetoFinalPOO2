import javax.swing.JFrame;

public class JogoMain {
	public static void main(String[] args) {

		JogoDaMemoria jogo = JogoDaMemoria.getInstance(); //singleton

		jogo.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		jogo.setLocationRelativeTo(null);
		jogo.setSize(580, 800);
		jogo.setVisible(true);

	}
}
