import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class LevelUm extends JFrame {
	// preciso aprender a fazer um array de imagens e implementar as imagens por um
	// for + random position

	//declarações 
	private String[] stringButtons = {"0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15"}; //16Buttons adicionados 
	private JButton[] bbotoes;																				  //para serem testados
	private JLabel score;
	private JLabel tempo;
	private JPanel panelcima = new JPanel();
	private JPanel buttonsPanel = new JPanel();
	private Random randonn = new Random();
	private int counter = 300;
	private boolean running = true;
	private boolean virar = true;

	private String[][] matriz = new String[4][4];
	private String[] coloridas = { "powerosas.jpg", "ben.jpg", "pony.png", "winx.jpg", "bravo.jpg", "coragem.jpg",
								   "trol.png", "jake.gif" }; // show.jpg
	
	private Icon[] icons = { new ImageIcon(getClass().getResource(coloridas[0])),
							 new ImageIcon(getClass().getResource(coloridas[1])), 
							 new ImageIcon(getClass().getResource(coloridas[2])),
							 new ImageIcon(getClass().getResource(coloridas[3])) };
	
	private ImageIcon botoesInterrogacao = new ImageIcon(getClass().getResource("ponti.jpg"));	
	
	
	//relogio tempo
	private Thread trd = new Thread(new Runnable() { 
		@Override
		public void run() {
			while (running) {
				// set text no label de contador
				//System.out.println(counter + " segundos");
				counter--;
				if (counter < 0)
					running = false;
				try {
					Thread.sleep(1000); // um segundo
				} catch (Exception e) {
				}
			}
		}
	});//end Thread
	
	public LevelUm() {
		super("Jogo da Memória - Facil");
		setLayout(new BorderLayout());
		
		score = new JLabel(); 							//fazer o score/ sistema de pontuação
		tempo = new JLabel();
		
		for( int j = 0; j < counter; j++) {
			tempo.setText("" + counter);
			getContentPane();

		}
		bbotoes = new JButton[stringButtons.length];
		panelcima = new JPanel();
		buttonsPanel = new JPanel();
		
		panelcima.setLayout(new GridLayout(1, 0)); 		// ainda nao arrumei o layout certo
		panelcima.setLayout(new GridLayout(1,0,5,5));	//por que nao funcionou os botoes para eu ver
		
		panelcima.add(tempo, BorderLayout.WEST);		//arrumando os layouts
		panelcima.add(score,BorderLayout.EAST);
		
		add(panelcima,BorderLayout.NORTH);
		add(buttonsPanel,BorderLayout.SOUTH); 			//.center

		
		bbotoes = new JButton[icons.length];
		stringButtons = new String[16];
		
		final String[] imgs = new String[coloridas.length * 2]; // duplicou o numero de imagens
		for (int i = 0; i < coloridas.length; i++) {
			imgs[i] = coloridas[i];
			imgs[coloridas.length + i] = coloridas[i];
		}
		
		Random r = new Random();
		for (int i = 0; i < matriz.length; i++) {
			for (int j = 0; j < matriz[i].length; j++) { // populou a matriz com Random
														 // existe um método chamado shuffle para isso
		
				int max = imgs.length - (i * matriz[i].length) - j;
				int value = r.nextInt(max);
				matriz[i][j] = imgs[value];
				String aux = imgs[max - 1];
				imgs[max - 1] = imgs[value];
				imgs[value] = aux;
			}
		}
		for (int i = 0; i < matriz.length; i++) { 		//matriz de icones
			for (int j = 0; j < matriz[i].length; j++) {
				System.out.print(matriz[i][j] + " ");
			}
			System.out.println();  // vendo se a matriz funciona
		}
		
		trd.start();
		
		for (int i = 0; i < imgs.length; i++) { //imgs.length
			// fazer a imagem virar e ter outra imagem
			// fazer o botao virar contendo uma imagem de cada lado
			// um lado com imagem "?" e outra com imagem para acertar
			//usando o metodo virar do grid, exemplo de slide da professora
			
			bbotoes[i] = new JButton(stringButtons[i]);
			bbotoes[i].setActionCommand("" + i);
			
			
			bbotoes[i].addActionListener(new ActionListener() {	
				@Override
				public void actionPerformed(ActionEvent e) {
					String cmd = e.getActionCommand();
					int id = Integer.parseInt(cmd);
		
					if (virar) {
						((JButton) e.getSource()).setIcon(botoesInterrogacao);
					} else {
						((JButton) e.getSource()).setIcon(new ImageIcon(getClass().getResource(coloridas[id])));
						virar = !virar;
		
					}
				}
			});// end Listener
			buttonsPanel.add(bbotoes[i]); // adicionando os botoes no
										  // panel de baixo 
			
		} // end for
		
	}// end construtor

}// end class


// tentando pegar as imagens direto do diretorio
//// String src = "";
//// java.io.File diretorio = new java.io.File(src);
//// String[] templates = diretorio.list();
//// ImageIcon[] icons = new ImageIcon[templates.length];
//// LevelUm[] listaImagens = new LevelUm[templates.length];
